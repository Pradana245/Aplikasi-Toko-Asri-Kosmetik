package com.example.onlineshop

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.onlineshop.data.model.Transaction
import com.example.onlineshop.data.repository.TransactionRepository
import com.google.firebase.FirebaseApp
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@ExperimentalCoroutinesApi
@RunWith(AndroidJUnit4::class)
class TransactionRepositoryInstrumentedTest {

    private lateinit var repository: TransactionRepository

    private val dummyTransaction = Transaction(
        orderId = "", // akan digenerate oleh repository
        userId = "",
        items = listOf(),
        totalPrice = 150000.0,
        status = "Pending",
        timestamp = System.currentTimeMillis(),
        customerName = "",
        customerPhone = "",
        customerEmail = "",
        customerAddress = ""
    )


    @Before
    fun setup() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        FirebaseApp.initializeApp(context)
        repository = TransactionRepository()
    }

    @Test
    fun placeOrder_shouldReturnTransactionWithGeneratedId() = runTest {
        val result = repository.placeOrder(dummyTransaction)
        assertNotNull(result)
        assertTrue(result?.orderId?.isNotEmpty() == true)
        assertEquals("Pending", result?.status)
    }

    @Test
    fun updatePaymentStatus_shouldChangeStatusToPaid() = runTest {
        val transaction = repository.placeOrder(dummyTransaction)
        val success = repository.updatePaymentStatus(transaction!!.orderId)
        assertTrue(success)

        val status = repository.getTransactionStatus(transaction.orderId)
        assertEquals("Paid", status)
    }

    @Test
    fun updateTransactionStatus_shouldChangeStatusCorrectly() = runTest {
        val transaction = repository.placeOrder(dummyTransaction)
        val result = repository.updateTransactionStatus(
            userId = transaction!!.userId,
            transactionId = transaction.orderId,
            newStatus = "Shipped"
        )
        assertTrue(result)

        val status = repository.getTransactionStatus(transaction.orderId)
        assertEquals("Shipped", status)
    }

    @Test
    fun getTransactionStatus_shouldReturnPendingIfNotFound() = runTest {
        val status = repository.getTransactionStatus("nonexistent_order_id")
        assertEquals("Pending", status)
    }

    @Test
    fun getTransactions_shouldReturnTransactionList() = runTest {
        val list = repository.getTransactions().first()
        assertNotNull(list)
        assertTrue(list is List<*>)
    }
}
