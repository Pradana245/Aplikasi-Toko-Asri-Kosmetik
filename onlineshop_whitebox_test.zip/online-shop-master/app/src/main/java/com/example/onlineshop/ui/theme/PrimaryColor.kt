package com.example.onlineshop.ui.theme

annotation class PrimaryColor
