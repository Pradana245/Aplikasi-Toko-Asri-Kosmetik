package com.example.onlineshop.data.repository

import com.example.onlineshop.data.model.Product
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.QuerySnapshot
import kotlinx.coroutines.tasks.await

class ProductRepository(private val db: FirebaseFirestore = FirebaseFirestore.getInstance()){
//class ProductRepository() {
//    private val db = FirebaseFirestore.getInstance()


    suspend fun addProductToFirestore(product: Product) {
        try {
            val snapshot = db.collection("products")
                .orderBy("id")
                .get()
                .await()

            val lastId = snapshot.documents.lastOrNull()?.getLong("id")?.toInt() ?: 0
            val newId = lastId + 1

            val newProduct = product.copy(id = newId)

            db.collection("products")
                .document(newId.toString())
                .set(newProduct)
                .await()
        } catch (e: Exception) {
            throw Exception("Failed to add product to Firestore: ${e.message}")
        }
    }


    suspend fun getProductsFromFirestore(): List<Product> {
        return try {
            val snapshot = db.collection("products").get().await()
            snapshot.toObjects(Product::class.java)
        } catch (e: Exception) {
            throw Exception("Failed to fetch products from Firestore: ${e.message}")
        }
    }

    suspend fun getProductById(productId: String?): Product? {
        return try {
            val document = db.collection("products").document(productId.toString()).get().await()
            document.toObject(Product::class.java)
        } catch (e: Exception) {
            throw Exception("Failed to fetch product with ID $productId: ${e.message}")
        }
    }

    suspend fun updateProductInFirestore(product: Product) {
        try {
            db.collection("products")
                .document(product.id.toString())
                .set(product)
                .await()
        } catch (e: Exception) {
            throw Exception("Failed to update product in Firestore: ${e.message}")
        }
    }

    suspend fun deleteProduct(productId: Int) {
        try {
            db.collection("products")
                .document(productId.toString())
                .delete()
                .await()
        } catch (e: Exception) {
            throw Exception("Failed to delete product from Firestore: ${e.message}")
        }
    }

    suspend fun updateProduct(productId: Int?, updateProduct: Product){
        try {
            db.collection("products")
                .document(productId.toString())
                .set(updateProduct)
                .await()
        } catch (e: Exception) {
            throw Exception("Failed to update product in Firestore: ${e.message}")
        }
    }

    suspend fun updateProductStock(productId: String, newStock: Int) {
        try {
            db.collection("products")
                .document(productId)
                .update("quantity", newStock)
                .await()
        } catch (e: Exception) {
            throw Exception("Failed to update product stock in Firestore: ${e.message}")
        }
    }

    fun mapQuerySnapshotToProductList(snapshot: QuerySnapshot): List<Product> {
        return snapshot.documents.mapNotNull { it.toObject(Product::class.java) }
    }

}
