package com.example.onlineshop.data.model

data class Transaction(
    val orderId: String = "",
    val userId: String = "",
    val items: List<CartItem> = emptyList(),
    val totalPrice: Double = 0.0,
    val status: String = "Pending",
    val timestamp: Long = System.currentTimeMillis(),
    val customerName: String = "",
    val customerPhone: String = "",
    val customerEmail: String = "",
    val customerAddress: String = "",
) {
    constructor() : this("", "", emptyList(), 0.0, "", 0, "", "", "", "")
}