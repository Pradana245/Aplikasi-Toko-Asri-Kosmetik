package com.example.onlineshop.ui.screen.user

import android.Manifest
import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Place
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import coil.compose.rememberAsyncImagePainter
import coil.request.ImageRequest
import com.example.onlineshop.R
import com.example.onlineshop.data.lib.DataStoreManager
import com.example.onlineshop.data.model.User
import com.example.onlineshop.data.repository.AuthRepository
import com.example.onlineshop.data.repository.UserProfileRepository
import com.example.onlineshop.ui.component.EditProfileDialog
import com.example.onlineshop.ui.component.ProfileInfoItem
import com.example.onlineshop.ui.component.ProfilePictureDialog
import com.example.onlineshop.utils.ImgurUploader
import com.example.onlineshop.utils.createImageFile
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Dispatchers

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserProfileScreen(
    authRepository: AuthRepository,
    userRepository: UserProfileRepository,
    dataStoreManager: DataStoreManager,
    onLogout: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val context = LocalContext.current

    // State variables
    var showLogoutDialog by rememberSaveable { mutableStateOf(false) }
    var showEditDialog by rememberSaveable { mutableStateOf(false) }
    var showProfilePictureDialog by rememberSaveable { mutableStateOf(false) }
    var userData by remember { mutableStateOf<User?>(null) }
    var isLoading by remember { mutableStateOf(false) }
    var selectedImageUri by rememberSaveable { mutableStateOf<Uri?>(null) }
    var cameraPhotoUri by rememberSaveable { mutableStateOf<Uri?>(null) }

    // Using remember to prevent recreation on recomposition
    val imgurUploader = remember { ImgurUploader(context) }

    // Function to load user data safely
    fun loadUserData() {
        coroutineScope.launch {
            try {
                isLoading = true
                userData = userRepository.getCurrentUserData()
            } catch (e: Exception) {
                if (e !is CancellationException) {
                    Toast.makeText(context, "Gagal untuk memuat data", Toast.LENGTH_SHORT).show()
                }
            } finally {
                isLoading = false
            }
        }
    }

    // Function to handle image upload
    fun uploadProfileImage(uri: Uri) {
        if (isLoading) return

        coroutineScope.launch {
            try {
                isLoading = true
                val uploadedUrl = withContext(Dispatchers.IO) {
                    imgurUploader.uploadImage(uri)
                }

                if (uploadedUrl != null) {
                    userRepository.updateProfilePicture(uploadedUrl.toString())
                    userData = userRepository.getCurrentUserData() // Refresh user data
                    Toast.makeText(context, "Profile picture updated", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, "Failed to upload image", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                if (e !is CancellationException) {
                    Toast.makeText(context, "Failed to update profile picture", Toast.LENGTH_SHORT).show()
                }
            } finally {
                isLoading = false
            }
        }
    }

    // Camera launcher
    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success ->
        if (success && cameraPhotoUri != null) {
            selectedImageUri = cameraPhotoUri
            uploadProfileImage(cameraPhotoUri!!)
        }
    }

    // Camera permission launcher
    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            try {
                val photoFile = context.createImageFile()
                cameraPhotoUri = FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    photoFile
                )
                cameraLauncher.launch(cameraPhotoUri)
            } catch (e: Exception) {
                Toast.makeText(context, "Failed to create camera file", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(context, "Perlu izin untuk mengakses kamera", Toast.LENGTH_SHORT).show()
        }
    }

    // Function to copy image to local storage
    fun Context.copyImageToLocalStorage(sourceUri: Uri): Uri? {
        return try {
            val destinationFile = createImageFile()

            contentResolver.openInputStream(sourceUri)?.use { inputStream ->
                destinationFile.outputStream().use { outputStream ->
                    inputStream.copyTo(outputStream)
                }
            }

            FileProvider.getUriForFile(
                this,
                "${packageName}.fileprovider",
                destinationFile
            )
        } catch (e: Exception) {
            null
        }
    }

    // Gallery launcher
    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val localUri = context.copyImageToLocalStorage(uri)
                if (localUri != null) {
                    selectedImageUri = localUri
                    uploadProfileImage(localUri)
                } else {
                    Toast.makeText(context, "Gagal untuk memproses gambar", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(context, "Gagal untuk memproses gambar", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Load user data when screen is first displayed
    LaunchedEffect(Unit) {
        loadUserData()
    }

    Scaffold(
        containerColor = Color.White,
        contentColor = Color.Black
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Main content
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Profile Picture & Name
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(contentAlignment = Alignment.BottomEnd) {
                            // Show selected image or default profile picture
                            val imagePainter = if (selectedImageUri != null) {
                                rememberAsyncImagePainter(
                                    ImageRequest.Builder(context)
                                        .data(selectedImageUri)
                                        .crossfade(true)
                                        .build()
                                )
                            } else if (userData?.profileImageUrl != null && userData?.profileImageUrl?.isNotEmpty() == true) {
                                rememberAsyncImagePainter(
                                    ImageRequest.Builder(context)
                                        .data(userData?.profileImageUrl)
                                        .crossfade(true)
                                        .error(R.drawable.profile_placeholder)
                                        .placeholder(R.drawable.profile_placeholder)
                                        .build()
                                )
                            } else {
                                painterResource(id = R.drawable.profile_placeholder)
                            }

                            Image(
                                painter = imagePainter,
                                contentDescription = "Foto Profil",
                                modifier = Modifier
                                    .size(130.dp)
                                    .clip(CircleShape)
                                    .border(3.dp, MaterialTheme.colorScheme.primary, CircleShape),
                                contentScale = ContentScale.Crop
                            )
                            IconButton(
                                onClick = { showProfilePictureDialog = true },
                                modifier = Modifier
                                    .size(32.dp)
                                    .background(MaterialTheme.colorScheme.primary, CircleShape)
                                    .border(2.dp, Color.White, CircleShape)
                            ) {
                                Icon(Icons.Filled.Edit, contentDescription = "Edit Foto Profil", tint = Color.White)
                            }
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = userData?.name ?: "Memuat...",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Personal Information Card
                ElevatedCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    shape = RoundedCornerShape(12.dp),
                    elevation = CardDefaults.elevatedCardElevation(1.dp),
                    colors = CardDefaults.elevatedCardColors(containerColor = Color.White),
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Informasi Pribadi",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            IconButton(
                                onClick = { showEditDialog = true },
                                enabled = !isLoading
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = "Edit Informasi",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                        Divider(color = MaterialTheme.colorScheme.outlineVariant, thickness = 1.dp)
                        ProfileInfoItem(Icons.Default.Email, "Email", userData?.email ?: "Loading...")
                        ProfileInfoItem(Icons.Default.Phone, "Nomor Telepon", userData?.phone ?: "Loading...")
                        ProfileInfoItem(Icons.Default.Place, "Alamat", userData?.address ?: "Loading...")
                    }
                }

                TextButton(
                    onClick = { showLogoutDialog = true },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 16.dp, horizontal = 8.dp)
                        .height(56.dp)
                        .border(1.dp, Color(0xFFD32F2F), RoundedCornerShape(12.dp)),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = Color.Transparent,
                        contentColor = Color(0xFFD32F2F)
                    ),
                    shape = RoundedCornerShape(12.dp),
                    enabled = !isLoading
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Logout,
                            contentDescription = "Logout Icon",
                            tint = Color(0xFFD32F2F),
                            modifier = Modifier.size(24.dp)
                        )
                        Text(
                            text = "Logout",
                            fontWeight = FontWeight.Normal,
                            style = MaterialTheme.typography.titleMedium,
                            color = Color(0xFFD32F2F)
                        )
                    }
                }
            }

            // Loading overlay
            if (isLoading) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.4f)),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                }
            }
        }
    }

    // Edit Profile Information Dialog
    if (showEditDialog) {
        EditProfileDialog(
            user = userData,
            onDismiss = { showEditDialog = false },
            onSave = { updatedUser ->
                coroutineScope.launch {
                    try {
                        isLoading = true
                        userRepository.updateUserProfile(updatedUser)
                        userData = userRepository.getCurrentUserData()
                    } catch (e: Exception) {
                        if (e !is CancellationException) {
                            Toast.makeText(context, "Gagal memperbarui informasi", Toast.LENGTH_SHORT).show()
                        }
                    } finally {
                        isLoading = false
                    }
                }
                showEditDialog = false
            }
        )
    }

    // Edit Profile Picture Dialog
    if (showProfilePictureDialog) {
        ProfilePictureDialog(
            onDismiss = { showProfilePictureDialog = false },
            onGallery = {
                galleryLauncher.launch("image/*")
                showProfilePictureDialog = false
            },
            onCamera = {
                cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                showProfilePictureDialog = false
            }
        )
    }

    // Logout Confirmation Dialog
    if (showLogoutDialog) {
        AlertDialog(
            onDismissRequest = { showLogoutDialog = false },
            title = { Text("Konfirmasi") },
            text = { Text("Apakah Anda yakin ingin keluar?") },
            confirmButton = {
                Button(
                    onClick = {
                        coroutineScope.launch {
                            try {
                                isLoading = true
                                authRepository.logout(dataStoreManager)
                                onLogout()
                            } catch (e: Exception) {
                                if (e !is CancellationException) {
                                    Toast.makeText(context, "Gagal logout", Toast.LENGTH_SHORT).show()
                                }
                            } finally {
                                isLoading = false
                            }
                        }
                        showLogoutDialog = false
                    },
                    enabled = !isLoading
                ) {
                    Text("Iya")
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showLogoutDialog = false },
                    enabled = !isLoading
                ) {
                    Text("Tidak")
                }
            }
        )
    }
}