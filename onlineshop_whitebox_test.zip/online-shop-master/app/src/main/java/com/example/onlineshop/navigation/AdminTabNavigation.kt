package com.example.onlineshop.navigation

import androidx.compose.foundation.layout.*
//noinspection UsingMaterialAndMaterial3Libraries
import androidx.compose.material.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.example.onlineshop.data.lib.DataStoreManager
import com.example.onlineshop.data.repository.AuthRepository
import com.example.onlineshop.data.repository.UserProfileRepository
import com.google.accompanist.systemuicontroller.rememberSystemUiController
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavController
import com.example.onlineshop.data.repository.TransactionRepository
import com.example.onlineshop.ui.component.AdminBottomNavigation
import com.example.onlineshop.ui.component.AdminTab
import com.example.onlineshop.ui.screen.admin.AdminDashboardScreen
import com.example.onlineshop.ui.screen.admin.AdminProfileScreen
import com.example.onlineshop.ui.screen.admin.AdminQueueScreen
import com.example.onlineshop.ui.viewModel.QueueViewModel

@Composable
fun AdminTabNavigation(
    authRepository: AuthRepository,
    userProfileRepository: UserProfileRepository,
    dataStoreManager: DataStoreManager,
    onLogout: () -> Unit,
    navController: NavController
) {
    var selectedTab by remember { mutableStateOf(AdminTab.Dashboard) }
    val systemUiController = rememberSystemUiController()
    val useDarkIcons = MaterialTheme.colors.isLight

    LaunchedEffect(Unit) {
        systemUiController.setSystemBarsColor(
            color = Color.Transparent,
            darkIcons = useDarkIcons
        )
    }

    Scaffold(
        bottomBar = {
            AdminBottomNavigation(selectedTab) { newTab ->
                selectedTab = newTab
            }
        }
    ) { paddingValues ->
        Column(modifier = Modifier.padding(paddingValues)) {
            when (selectedTab) {
                AdminTab.Dashboard -> AdminDashboardScreen(navController)
                AdminTab.Queue -> {
                    val repository = remember { TransactionRepository() }
                    val adminQueueViewModel = viewModel<QueueViewModel>(
                        factory = viewModelFactory {
                            initializer {
                                QueueViewModel(repository)
                            }
                        }
                    )

                    AdminQueueScreen(
                        viewModel = adminQueueViewModel,
                        onTransactionConfirm = { transaction ->
                            adminQueueViewModel.confirmTransaction(transaction)
                            navController.navigateUp()
                        }
                    )
                }
                AdminTab.Profile -> AdminProfileScreen(
                    authRepository = authRepository,
                    dataStoreManager = dataStoreManager,
                    onLogout = onLogout
                )
            }
        }
    }
}
