package com.example.onlineshop.ui.viewModel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.onlineshop.data.model.Transaction
import com.example.onlineshop.data.repository.ProductRepository
import com.example.onlineshop.data.repository.TransactionRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class QueueViewModel(
    private val transactionRepository: TransactionRepository = TransactionRepository(),
    private val productRepository: ProductRepository = ProductRepository()
) : ViewModel() {

    private val _isLoading = MutableStateFlow(true)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    // Add refresh trigger to force re-collection
    private val _refreshTrigger = MutableStateFlow(0)

    // Flow of paid transactions from all users, sorted by timestamp (newest first)
    @OptIn(ExperimentalCoroutinesApi::class)
    val paidTransactions: Flow<List<Transaction>> = _refreshTrigger
        .flatMapLatest {
            transactionRepository.getAllTransactions()
                .map { transactions ->
                    _isLoading.value = false
                    transactions
                        .filter { it.status == "Paid" }
                        .sortedByDescending { it.timestamp }
                }
                .catch { error ->
                    _isLoading.value = false
                    emit(emptyList())
                }
                .onStart { _isLoading.value = true }
        }

    // Function to manually refresh transactions
    fun refreshTransactions() {
        _refreshTrigger.value = _refreshTrigger.value + 1
    }

    // Function to update transaction status and reduce product stock
    fun confirmTransaction(transaction: Transaction) {
        viewModelScope.launch {
            try {
                // First, update the transaction status
                transactionRepository.updateTransactionStatus(
                    userId = transaction.userId,
                    transactionId = transaction.orderId,
                    newStatus = "Confirmed"
                )

                // Second, reduce the stock for each product in the transaction
                transaction.items.forEach { cartItem ->
                    val productId = cartItem.product.id
                    val quantity = cartItem.quantity

                    // Get current product to check current stock
                    val currentProduct = productRepository.getProductById(productId.toString())

                    // Calculate new stock
                    val newStock = (currentProduct?.quantity ?: 0) - quantity

                    // Update the product stock
                    productRepository.updateProductStock(productId.toString(), newStock)
                }

                // Small delay to ensure Firestore updates complete
                kotlinx.coroutines.delay(500)

                // Refresh the transactions list
                refreshTransactions()
            } catch (e: Exception) {
                println("Error confirming transaction: ${e.message}")
            }
        }
    }
}