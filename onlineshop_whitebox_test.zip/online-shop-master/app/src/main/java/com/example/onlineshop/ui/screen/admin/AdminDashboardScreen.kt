package com.example.onlineshop.ui.screen.admin

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.example.onlineshop.data.model.Product
import com.example.onlineshop.data.repository.ProductRepository
import com.example.onlineshop.ui.component.LoadingIndicator
import com.example.onlineshop.utils.formatCurrency
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

@Composable
fun AdminDashboardScreen(
    navController: NavController,
) {
    val coroutineScope = rememberCoroutineScope()
    var products by remember { mutableStateOf(emptyList<Product>()) }
    var isLoading by remember { mutableStateOf(true) }
    var searchQuery by remember { mutableStateOf("") }
    var filteredProducts by remember { mutableStateOf(emptyList<Product>()) }
    var showDeleteDialog by remember { mutableStateOf(false) }
    var productToDelete by remember { mutableStateOf<Product?>(null) }
    val productRepository = remember { ProductRepository() }
    var isDeleting by remember { mutableStateOf(false) }
    var showSnackbar by remember { mutableStateOf(false) }
    var snackbarMessage by remember { mutableStateOf("") }
    val scaffoldState = rememberScaffoldState()

    LaunchedEffect(Unit) {
        loadProducts(coroutineScope, productRepository) { newProducts ->
            products = newProducts
            filteredProducts = newProducts
            isLoading = false
        }
    }

    LaunchedEffect(searchQuery, products) {
        filteredProducts = if (searchQuery.isEmpty()) {
            products
        } else {
            products.filter {
                it.title.contains(searchQuery, ignoreCase = true) ||
                        it.description?.contains(searchQuery, ignoreCase = true) == true
            }
        }
    }

    LaunchedEffect(showSnackbar) {
        if (showSnackbar) {
            scaffoldState.snackbarHostState.showSnackbar(snackbarMessage)
            showSnackbar = false
        }
    }

    if (showDeleteDialog && productToDelete != null) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text("Konfirmasi Hapus") },
            text = { Text("Apakah Anda yakin ingin menghapus produk '${productToDelete?.title}'?") },
            confirmButton = {
                Button(
                    onClick = {
                        coroutineScope.launch {
                            isDeleting = true
                            try {
                                productToDelete?.id?.let { productId ->
                                    productRepository.deleteProduct(productId)
                                    loadProducts(coroutineScope, productRepository) { newProducts ->
                                        products = newProducts
                                        filteredProducts = if (searchQuery.isEmpty()) {
                                            newProducts
                                        } else {
                                            newProducts.filter {
                                                it.title.contains(searchQuery, ignoreCase = true) ||
                                                        it.description?.contains(searchQuery, ignoreCase = true) == true
                                            }
                                        }
                                    }
                                    snackbarMessage = "Produk berhasil dihapus"
                                    showSnackbar = true
                                }
                            } catch (e: Exception) {
                                snackbarMessage = "Gagal menghapus produk: ${e.message}"
                                showSnackbar = true
                            } finally {
                                isDeleting = false
                                showDeleteDialog = false
                                productToDelete = null
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(backgroundColor = Color.Red)
                ) {
                    if (isDeleting) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            color = Color.White,
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                    }
                    Text("Hapus", color = Color.White)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = {
                        showDeleteDialog = false
                        productToDelete = null
                    }
                ) {
                    Text("Batal")
                }
            }
        )
    }

    Scaffold(
        scaffoldState = scaffoldState,
        topBar = {
            TopAppBar(
                title = { Text("Manajemen Produk", fontWeight = FontWeight.Bold) },
                backgroundColor = MaterialTheme.colors.surface,
                elevation = 4.dp
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { navController.navigate("add_product") },
                backgroundColor = MaterialTheme.colors.primary
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Add Product",
                    tint = Color.White
                )
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .padding(paddingValues)
                .fillMaxSize()
                .background(Color(0xFFF5F5F5))
        ) {
            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                placeholder = { Text("Cari Produk...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                shape = RoundedCornerShape(8.dp),
                singleLine = true,
                colors = TextFieldDefaults.outlinedTextFieldColors(
                    focusedBorderColor = MaterialTheme.colors.primary,
                    unfocusedBorderColor = Color.Gray,
                    backgroundColor = Color.White
                )
            )

            // Statistics Cards
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatisticsCard(
                    title = "Total Produk",
                    value = "${products.size}",
                    modifier = Modifier.weight(1f),
                    color = MaterialTheme.colors.primary,
                )
                StatisticsCard(
                    title = "Stok Sedikit",
                    value = "${products.count { it.quantity < 10 }}",
                    modifier = Modifier.weight(1f),
                    color = Color(0xFFFF9800)
                )
                StatisticsCard(
                    title = "Stok Kosong",
                    value = "${products.count { it.quantity <= 0 }}",
                    modifier = Modifier.weight(1f),
                    color = Color(0xFFF44336)
                )
            }

            if (isLoading) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    LoadingIndicator()
                }
            } else if (filteredProducts.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Produk tidak ditemukan", color = Color.Gray)
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(vertical = 8.dp)
                ) {
                    items(filteredProducts) { product ->
                        ProductItem(
                            product = product,
                            onEditClick = { navController.navigate("edit_product/${product.id}") },
                            onDeleteClick = {
                                productToDelete = product
                                showDeleteDialog = true
                            }
                        )
                    }
                }
            }
        }
    }
}

private fun loadProducts(
    coroutineScope: CoroutineScope,
    productRepository: ProductRepository,
    onProductsLoaded: (List<Product>) -> Unit
) {
    coroutineScope.launch {
        try {
            val newProducts = productRepository.getProductsFromFirestore()
            onProductsLoaded(newProducts)
        } catch (e: Exception) {
            onProductsLoaded(emptyList())
        }
    }
}

@Composable
fun StatisticsCard(
    title: String,
    value: String,
    modifier: Modifier = Modifier,
    color: Color
) {
    Card(
        modifier = modifier
            .height(110.dp)
            .padding(bottom = 16.dp),
        elevation = 2.dp,
        shape = RoundedCornerShape(8.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = value,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = color
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = title,
                fontSize = 14.sp,
                color = Color.Gray,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun ProductItem(
    product: Product,
    onEditClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth(),
        elevation = 2.dp,
        shape = RoundedCornerShape(8.dp),
        backgroundColor = Color.White
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Product Image
            AsyncImage(
                model = product.image,
                contentDescription = product.title,
                modifier = Modifier
                    .size(60.dp)
                    .clip(RoundedCornerShape(4.dp)),
                contentScale = ContentScale.Fit
            )

            Spacer(modifier = Modifier.width(12.dp))

            // Product Details
            Column(
                modifier = Modifier
                    .weight(1.5f)
                    .clickable { onEditClick() }
            ) {
                Text(
                    text = product.title,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "Kategori: ${product.category}",
                    maxLines = 1,
                )

                val stockColor = when {
                    product.quantity <= 0 -> Color.Red
                    product.quantity < 10 -> Color(0xFFFF9800) // Orange
                    else -> Color(0xFF4CAF50) // Green
                }

                Text(
                    text = "Stok: ${product.quantity}",
                    maxLines = 1,
                    fontWeight = FontWeight.Medium,
                    color = stockColor
                )
                Text(
                    text = formatCurrency(product.price),
                    maxLines = 1,
                    fontWeight = FontWeight.Medium
                )
            }



            // Action Buttons
            Row(
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.End
            ) {
                // Edit Button
                IconButton(onClick = onEditClick) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = "Edit",
                        tint = MaterialTheme.colors.secondary
                    )
                }

                // Delete Button
                IconButton(onClick = onDeleteClick) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Delete",
                        tint = Color.Red
                    )
                }
            }
        }
    }
}

// Extension property for Product to ensure quantity is never null
val Product.quantity: Int
    get() = this.quantity ?: 0