package com.example.onlineshop

import com.example.onlineshop.data.model.Product
import com.example.onlineshop.data.repository.ProductRepository
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.QuerySnapshot
import junit.framework.TestCase.assertEquals
import kotlinx.coroutines.ExperimentalCoroutinesApi
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.InjectMocks
import org.mockito.Mock
import org.mockito.Mockito.mock
import org.mockito.Mockito.`when`
import org.mockito.MockitoAnnotations
import org.mockito.junit.MockitoJUnitRunner

@ExperimentalCoroutinesApi
@RunWith(MockitoJUnitRunner::class)
class ProductRepositoryTest {

    @Mock
    private lateinit var mockFirestore: FirebaseFirestore

    private lateinit var repository: ProductRepository

    @Before
    fun setup() {
        MockitoAnnotations.openMocks(this)
        repository = ProductRepository(mockFirestore)
    }

    @Test
    fun `mapQuerySnapshotToProductList should return correct product list`() {
        // Arrange
        val mockQuerySnapshot = mock(QuerySnapshot::class.java)
        val mockDocument1 = mock(DocumentSnapshot::class.java)
        val mockDocument2 = mock(DocumentSnapshot::class.java)

        val product1 = Product(1, "Baju", 100.0, "Deskripsi", "Kategori", "image.jpg", 10, "Toko A")
        val product2 = Product(2, "Celana", 150.0, "Deskripsi", "Kategori", "image2.jpg", 5, "Toko B")

        `when`(mockDocument1.toObject(Product::class.java)).thenReturn(product1)
        `when`(mockDocument2.toObject(Product::class.java)).thenReturn(product2)
        `when`(mockQuerySnapshot.documents).thenReturn(listOf(mockDocument1, mockDocument2))

        // Act
        val result = repository.mapQuerySnapshotToProductList(mockQuerySnapshot)

        // Assert
        assertEquals(2, result.size)
        assertEquals("Baju", result[0].title)
        assertEquals("Celana", result[1].title)
    }
}