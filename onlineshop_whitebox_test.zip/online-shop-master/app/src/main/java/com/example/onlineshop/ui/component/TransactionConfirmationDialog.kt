package com.example.onlineshop.ui.component

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.onlineshop.data.model.Transaction
import com.example.onlineshop.utils.formatCurrency

@Composable
fun TransactionConfirmationDialog(
    transaction: Transaction,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Konfirmasi Transaksi")
        },
        text = {
            Column {
                Text("Apakah Anda yakin ingin mengkonfirmasi transaksi ini?")

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Order #${transaction.orderId}",
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text("Customer: ${transaction.customerName}")
                Text("Total: ${formatCurrency(transaction.totalPrice)}")
                Text("Jumlah Item: ${transaction.items.size}")
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirm
            ) {
                Text("Konfirmasi")
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss
            ) {
                Text("Batal")
            }
        }
    )
}