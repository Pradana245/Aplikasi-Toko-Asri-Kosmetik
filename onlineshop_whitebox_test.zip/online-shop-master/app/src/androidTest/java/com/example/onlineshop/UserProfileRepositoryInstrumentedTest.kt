package com.example.onlineshop

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.onlineshop.data.model.User
import com.example.onlineshop.data.repository.UserProfileRepository
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@ExperimentalCoroutinesApi
@RunWith(AndroidJUnit4::class)
class UserProfileRepositoryInstrumentedTest {

    private lateinit var repository: UserProfileRepository
    private lateinit var auth: FirebaseAuth
    private lateinit var firestore: FirebaseFirestore

    private val dummyUser = User(
        name = "freyana",
        email = "freya@gmail.com",
        phone = "081294930231",
        address = "Yogyakarta",
        role = "user",
        profileImageUrl = "https://example.com/profile.jpg"
    )

    @Before
    fun setup() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        FirebaseApp.initializeApp(context)
        auth = FirebaseAuth.getInstance()
        firestore = FirebaseFirestore.getInstance()

        // Login ke Firebase dengan akun dummy
        auth.signInWithEmailAndPassword("freya@gmail.com", "freya123").await()

        // Simpan user awal ke Firestore (jika belum ada)
        val uid = auth.currentUser?.uid ?: error("User not logged in")
        firestore.collection("users").document(uid).set(dummyUser.copy(uid = uid)).await()

        // Inisialisasi repository
        repository = UserProfileRepository(auth, firestore)
    }

    @Test
    fun getCurrentUserData_shouldReturnValidUser() = runTest {
        val user = repository.getCurrentUserData()
        assertNotNull(user)
        assertEquals("freya@gmail.com", user?.email)
    }

    @Test
    fun updateUserProfile_shouldChangeFieldsCorrectly() = runTest {
        val updatedUser = dummyUser.copy(name = "Freya Updated", phone = "08987654321")
        repository.updateUserProfile(updatedUser)

        val user = repository.getCurrentUserData()
        assertNotNull(user)
        assertEquals("Freya Updated", user?.name)
        assertEquals("08987654321", user?.phone)
    }

    @Test
    fun updateProfilePicture_shouldUpdateUrlSuccessfully() = runTest {
        val newUrl = "https://example.com/new-photo.jpg"
        repository.updateProfilePicture(newUrl)

        val user = repository.getCurrentUserData()
        assertEquals(newUrl, user?.profileImageUrl)
    }

    @Test
    fun getUserRole_shouldReturnCorrectRole() = runTest {
        val role = repository.getUserRole("freya@gmail.com")
        assertEquals("user", role)
    }
}
