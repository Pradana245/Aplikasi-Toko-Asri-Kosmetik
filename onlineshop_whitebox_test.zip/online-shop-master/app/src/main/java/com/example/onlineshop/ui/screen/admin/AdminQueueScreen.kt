package com.example.onlineshop.ui.screen.admin

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.TopAppBar
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.onlineshop.data.model.Transaction
import com.example.onlineshop.ui.component.AdminTransactionItem
import com.example.onlineshop.ui.component.TransactionConfirmationDialog
import com.example.onlineshop.ui.component.TransactionSuccessDialog
import com.example.onlineshop.ui.viewModel.QueueViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminQueueScreen(
    viewModel: QueueViewModel = viewModel(),
    onTransactionConfirm: (Transaction) -> Unit
) {
    val transactions by viewModel.paidTransactions.collectAsState(initial = emptyList())
    val isLoading by viewModel.isLoading.collectAsState()
    var selectedTransaction by remember { mutableStateOf<Transaction?>(null) }
    var showSuccessDialog by remember { mutableStateOf(false) }
    var confirmedTransaction by remember { mutableStateOf<Transaction?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Antrian Pembayaran", fontWeight = FontWeight.Bold, fontSize = 20.sp) },
                backgroundColor = MaterialTheme.colorScheme.surface,
                elevation = 4.dp
            )
        },
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            if (isLoading) {
                CircularProgressIndicator(
                    modifier = Modifier.align(Alignment.Center)
                )
            } else if (transactions.isEmpty()) {
                EmptyTransactionList(
                    modifier = Modifier.align(Alignment.Center)
                )
            } else {
                TransactionList(
                    transactions = transactions,
                    onConfirmClick = { transaction ->
                        selectedTransaction = transaction
                    }
                )
            }
        }
    }

    // Confirmation Dialog
    selectedTransaction?.let { transaction ->
        TransactionConfirmationDialog(
            transaction = transaction,
            onDismiss = { selectedTransaction = null },
            onConfirm = {
                confirmedTransaction = transaction
                viewModel.confirmTransaction(transaction) // Use the new method here
                selectedTransaction = null
                showSuccessDialog = true
            }
        )
    }

    // Success Dialog
    if (showSuccessDialog && confirmedTransaction != null) {
        TransactionSuccessDialog(
            transaction = confirmedTransaction!!,
            onDismiss = {
                showSuccessDialog = false
                confirmedTransaction = null
            }
        )
    }
}

@Composable
fun TransactionList(
    transactions: List<Transaction>,
    onConfirmClick: (Transaction) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(transactions) { transaction ->
            AdminTransactionItem(
                transaction = transaction,
                onConfirmClick = { onConfirmClick(transaction) }
            )
        }
    }
}

@Composable
fun EmptyTransactionList(modifier: Modifier = Modifier) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Default.Receipt,
            contentDescription = "No Transactions",
            modifier = Modifier.size(72.dp),
            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
        )

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Tidak ada transaksi",
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "Belum ada transaksi yang sudah dibayar",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 32.dp)
        )
    }
}