package com.example.onlineshop

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.onlineshop.data.model.Product
import com.example.onlineshop.data.repository.CartRepository
import com.google.firebase.FirebaseApp
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@ExperimentalCoroutinesApi
@RunWith(AndroidJUnit4::class)
class CartRepositoryInstrumentedTest {

    private lateinit var cartRepository: CartRepository

    private val testProduct = Product(
        id = 1001,
        title = "Lipstick Red Matte",
        price = 75000.0,
        description = "Long-lasting matte lipstick",
        category = "Makeup",
        image = "https://example.com/image.png",
        quantity = 10
    )

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        FirebaseApp.initializeApp(context) // Inisialisasi Firebase agar bisa dipakai
        cartRepository = CartRepository()
    }

    @Test
    fun addToCart_updatesCartItems() = runTest {
        cartRepository.addToCart(testProduct, 2)

        val items = cartRepository.cartItems.value
        assertEquals(1, items.size)
        assertEquals(2, items[0].quantity)
        assertEquals(testProduct.title, items[0].product.title)
    }

    @Test
    fun removeFromCart_deletesItem() = runTest {
        cartRepository.addToCart(testProduct, 1)
        cartRepository.removeFromCart(testProduct.id)

        val items = cartRepository.cartItems.value
        assertTrue(items.isEmpty())
    }

    @Test
    fun updateQuantity_changesItemAmount() = runTest {
        cartRepository.addToCart(testProduct, 1)
        cartRepository.updateQuantity(testProduct.id, 3)

        val item = cartRepository.cartItems.value.find { it.product.id == testProduct.id }
        assertNotNull(item)
        assertEquals(3, item?.quantity)
    }

    @Test
    fun clearCart_removesAllItems() = runTest {
        cartRepository.addToCart(testProduct, 1)
        cartRepository.clearCart()

        assertTrue(cartRepository.cartItems.value.isEmpty())
        assertEquals(0.0, cartRepository.totalPrice.value, 0.001)
        assertEquals(0, cartRepository.itemCount.value)
    }
}
