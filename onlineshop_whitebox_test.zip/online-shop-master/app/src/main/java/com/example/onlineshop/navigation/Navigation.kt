package com.example.onlineshop.navigation

//noinspection UsingMaterialAndMaterial3Libraries
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.onlineshop.data.lib.DataStoreManager
import com.example.onlineshop.data.repository.AuthRepository
import com.example.onlineshop.data.repository.UserProfileRepository
import com.example.onlineshop.ui.screen.admin.AddProductScreen
import com.example.onlineshop.ui.screen.admin.EditProductScreen
import com.example.onlineshop.ui.screen.user.ProductDetailScreen
import com.example.onlineshop.ui.screen.user.CartScreen
import com.example.onlineshop.ui.screen.user.CheckoutScreen
import com.example.onlineshop.ui.screen.user.ConfirmationPaymentScreen
import com.example.onlineshop.ui.viewModel.CartViewModel

@Composable
fun Navigation(
    role: String,
    authRepository: AuthRepository,
    userProfileRepository: UserProfileRepository,
    dataStoreManager: DataStoreManager,
    onLogout: () -> Unit,
    cartViewModel: CartViewModel = viewModel()
) {
    println("Role Navigation: $role")

    val rememberedRole = remember { role }

    when (rememberedRole) {
        "admin" -> {
            val navController = rememberNavController()

            NavHost(navController = navController, startDestination = "admin_screen") {
                composable("admin_screen"){
                    AdminTabNavigation(
                        authRepository = authRepository,
                        userProfileRepository = userProfileRepository,
                        dataStoreManager = dataStoreManager,
                        onLogout = onLogout,
                        navController = navController
                    )
                }
                composable("edit_product/{productId}") { backStackEntry ->
                    val productId = backStackEntry.arguments?.getString("productId")?.toIntOrNull()
                    EditProductScreen(navController, productId)
                }
                composable("add_product") {
                    AddProductScreen(navController)
                }
            }
        }
        else -> {
            val navController = rememberNavController()

            NavHost(navController = navController, startDestination = "user_screen") {
                composable("user_screen") {
                    TabNavigation(
                        authRepository = authRepository,
                        userProfileRepository = userProfileRepository,
                        dataStoreManager = dataStoreManager,
                        onLogout = onLogout,
                        navController = navController
                    )
                }
                composable("detail/{productId}") { backStackEntry ->
                    val productId = backStackEntry.arguments?.getString("productId")
                    ProductDetailScreen(productId, goToCart = { navController.navigate("cart") })
                }
                composable("cart") {
                    CartScreen(
                        onCheckout = { navController.navigate("checkout") },
                        navController = navController
                    )
                }
                composable("checkout") {
                    CheckoutScreen(
                        navController = navController
                    )
                }
                composable(
                    "confirmation_payment/{transactionId}/{totalAmount}",
                    arguments = listOf(
                        navArgument("transactionId") { type = NavType.StringType },
                        navArgument("totalAmount") { type = NavType.FloatType }
                    )
                ) { backStackEntry ->
                    val transactionId = backStackEntry.arguments?.getString("transactionId") ?: ""
                    val totalAmount = backStackEntry.arguments?.getFloat("totalAmount") ?: 0f
                    ConfirmationPaymentScreen(transactionId, totalAmount.toDouble()) {
                        navController.popBackStack()
                    }
                }
            }
        }
    }
}
