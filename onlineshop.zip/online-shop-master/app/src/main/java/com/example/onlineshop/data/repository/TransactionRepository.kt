package com.example.onlineshop.data.repository

import com.example.onlineshop.data.model.Transaction
import com.example.onlineshop.data.model.User
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import kotlin.random.Random

class TransactionRepository {
    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()

    // Get current user ID
    private val userId: String
        get() = auth.currentUser?.uid ?: "guest"

    // Collection reference for transactions of the current user
    private val transactionsCollection
        get() = db.collection("users").document(userId).collection("transactions")

    suspend fun placeOrder(transaction: Transaction): Transaction? {
        return try {
            val transactionId = Random.nextInt(100000, 999999).toString()

            val userDoc = db.collection("users").document(userId).get().await()
            val user = userDoc.toObject(User::class.java)

            val transactionWithUserData = transaction.copy(
                orderId = transactionId,
                userId = userId,
                customerName = user?.name ?: "",
                customerPhone = user?.phone ?: "",
                customerEmail = user?.email ?: "",
                customerAddress = user?.address ?: ""
            )

            transactionsCollection
                .document(transactionId)
                .set(transactionWithUserData)
                .await()

            transactionWithUserData
        } catch (e: Exception) {
            null
        }
    }

    fun getTransactions(): Flow<List<Transaction>> = callbackFlow {
        val listener = transactionsCollection
            .addSnapshotListener { snapshot, e ->
                if (e != null) {
                    close(e)
                    return@addSnapshotListener
                }
                val transactions = snapshot?.toObjects(Transaction::class.java) ?: emptyList()
                trySend(transactions)
            }
        awaitClose { listener.remove() }
    }

    // Get a specific transaction
    suspend fun getAdminTransaction(userId: String, transactionId: String): Transaction? {
        return try {
            val doc = db.collection("users")
                .document(userId)
                .collection("transactions")
                .document(transactionId)
                .get()
                .await()

            if (doc.exists()) {
                doc.toObject(Transaction::class.java)
            } else {
                null
            }
        } catch (e: Exception) {
            null
        }
    }

    fun getAllTransactions(): Flow<List<Transaction>> = callbackFlow {
        // Reference to the "users" collection
        val usersCollection = db.collection("users")

        // Listen for changes in the users collection
        val listener = usersCollection.addSnapshotListener { usersSnapshot, usersError ->
            if (usersError != null) {
                close(usersError)
                return@addSnapshotListener
            }

            // Process the snapshot in a coroutine to avoid blocking the listener
            try {
                val allTransactions = mutableListOf<Transaction>()

                usersSnapshot?.documents?.forEach { userDoc ->
                    val userId = userDoc.id

                    // For each user, get their transactions subcollection
                    userDoc.reference.collection("transactions")
                        .get()
                        .addOnSuccessListener { transactionsSnapshot ->
                            // Convert to Transaction objects and add userId if not present
                            val userTransactions = transactionsSnapshot.toObjects(Transaction::class.java)
                                .map { transaction ->
                                    if (transaction.userId.isBlank()) {
                                        transaction.copy(userId = userId)
                                    } else {
                                        transaction
                                    }
                                }

                            // Add to our collection
                            allTransactions.addAll(userTransactions)

                            // Send the combined list
                            trySend(allTransactions)
                        }
                        .addOnFailureListener { e ->
                            // Just log the error but continue processing
                            println("Error getting transactions for user $userId: ${e.message}")
                        }
                }
            } catch (e: Exception) {
                close(e)
            }
        }

        awaitClose { listener.remove() }
    }

    suspend fun updateTransactionStatus(userId: String, transactionId: String, newStatus: String): Boolean {
        return try {
            db.collection("users")
                .document(userId)
                .collection("transactions")
                .document(transactionId)
                .update("status", newStatus)
                .await()
            true
        } catch (e: Exception) {
            false
        }
    }

    suspend fun updatePaymentStatus(transactionId: String): Boolean {
        return try {
            transactionsCollection
                .document(transactionId)
                .update("status", "Paid")
                .await()
            true
        } catch (e: Exception) {
            false
        }
    }

    suspend fun getTransactionStatus(transactionId: String): String {
        return try {
            val documentSnapshot = transactionsCollection
                .document(transactionId)
                .get()
                .await()

            return if (documentSnapshot.exists()) {
                documentSnapshot.getString("status") ?: "Pending"
            } else {
                "Pending"
            }
        } catch (e: Exception) {
            return "Pending"
        }
    }
}
