package com.example.onlineshop.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFAA96DA)
val PurpleGrey80 = Color(0xFF957DAD)
val Pink80 = Color(0xFFE5B3D4)

val Purple40 = Color(0xFF6A5ACD)
val PurpleGrey40 = Color(0xFF4A4E69)
val Pink40 = Color(0xFF9D4EDD)