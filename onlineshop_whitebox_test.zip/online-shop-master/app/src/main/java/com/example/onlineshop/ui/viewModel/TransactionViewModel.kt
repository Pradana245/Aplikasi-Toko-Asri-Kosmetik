package com.example.onlineshop.ui.viewModel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.onlineshop.data.model.CartItem
import com.example.onlineshop.data.model.Transaction
import com.example.onlineshop.data.repository.TransactionRepository
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class TransactionViewModel(private val repository: TransactionRepository = TransactionRepository()) : ViewModel() {

    private val _isOrderPlaced = MutableStateFlow(false)
    val isOrderPlaced: StateFlow<Boolean> = _isOrderPlaced

    private val _isStatusUpdated = MutableStateFlow(false)
    val isStatusUpdated: StateFlow<Boolean> = _isStatusUpdated

    // Add a state flow for orderId
    private val _orderId = MutableStateFlow("")
    val orderId: StateFlow<String> = _orderId

    // Add a state flow for totalAmount
    private val _totalAmount = MutableStateFlow(0.0)
    val totalAmount: StateFlow<Double> = _totalAmount

    val cartViewModel: CartViewModel = CartViewModel()

    private val _transactions = MutableStateFlow<List<Transaction>>(emptyList())
    val transactions: StateFlow<List<Transaction>> = _transactions

    init {
        viewModelScope.launch {
            repository.getTransactions().collect { transactionList ->
                Log.d("TransactionViewModel", "Transactions: $transactionList")
                _transactions.value = transactionList
            }
        }
    }

    fun placeOrder(cartItems: List<CartItem>, totalPrice: Double) {
        viewModelScope.launch {
            Log.d("TransactionViewModel", "Placing order with ${cartItems.size} items, total: $totalPrice")

            val order = Transaction(
                items = cartItems,
                totalPrice = totalPrice
            )

            val savedOrder = repository.placeOrder(order)

            if (savedOrder != null) {
                _isOrderPlaced.value = true

                val generatedOrderId = savedOrder.orderId ?: ""
                Log.d("TransactionViewModel", "Generated order ID: $generatedOrderId")

                _orderId.value = generatedOrderId
                _totalAmount.value = totalPrice

                Log.d("TransactionViewModel", "After setting values - orderId: ${_orderId.value}, totalAmount: ${_totalAmount.value}")

                cartViewModel.clearCart()
            } else {
                Log.e("TransactionViewModel", "Failed to place order")
            }
        }
    }


    fun resetOrderId() {
        _orderId.value = ""
        _isOrderPlaced.value = false
    }

    fun getTransactionStatus(transactionId: String, callback: (String) -> Unit) {
        viewModelScope.launch {
            try {
                val status = repository.getTransactionStatus(transactionId)
                callback(status)
                Log.d("TransactionViewModel", "Transaction status for $transactionId: $status")
            } catch (e: Exception) {
                Log.e("TransactionViewModel", "Error getting transaction status", e)
                callback("Pending")
            }
        }
    }

    fun markAsPaid(transactionId: String, callback: (Boolean) -> Unit) {
        viewModelScope.launch {
            try {
                val success = repository.updatePaymentStatus(transactionId)
                _isStatusUpdated.value = success
                callback(success)
                Log.d("TransactionViewModel", "Mark as paid result for $transactionId: $success")
            } catch (e: Exception) {
                Log.e("TransactionViewModel", "Error marking transaction as paid", e)
                callback(false)
            }
        }
    }
}