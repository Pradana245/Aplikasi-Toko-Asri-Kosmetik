package com.example.onlineshop

import com.example.onlineshop.data.repository.AuthRepository
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import io.mockk.every
import io.mockk.mockk
import io.mockk.mockkStatic
import junit.framework.TestCase.assertEquals
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runTest
import org.junit.Before
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class AuthRepositoryTest {

    private lateinit var auth: FirebaseAuth
    private lateinit var firestore: FirebaseFirestore
    private lateinit var repository: AuthRepository

    @Before
    fun setUp() {
        auth = mockk(relaxed = true)
        firestore = mockk(relaxed = true)
        mockkStatic(FirebaseAuth::class)
        mockkStatic(FirebaseFirestore::class)
        every { FirebaseAuth.getInstance() } returns auth
        every { FirebaseFirestore.getInstance() } returns firestore

        repository = AuthRepository()
    }

    @Test
    fun `registerUser should fail when email or password is blank`() = runTest {
        repository.registerUser(
            email = "",
            password = "",
            name = "John",
            phone = "123456",
            address = "Test Address",
            role = "user",
            profileImageUrl = "url"
        ) { success, message ->
            assertEquals(false, success)
            assertEquals("Email dan password tidak boleh kosong", message)
        }
    }

    // Tambahan pengujian untuk keberhasilan registrasi dan exception dapat Anda tambahkan juga
}