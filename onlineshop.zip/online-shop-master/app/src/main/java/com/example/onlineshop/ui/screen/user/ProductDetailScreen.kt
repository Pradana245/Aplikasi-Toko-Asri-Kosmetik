package com.example.onlineshop.ui.screen.user

import androidx.activity.compose.LocalOnBackPressedDispatcherOwner
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.compose.rememberNavController
import coil.compose.AsyncImage
import com.example.onlineshop.data.repository.ProductRepository
import com.example.onlineshop.ui.viewModel.ProductDetailViewModel
import com.example.onlineshop.utils.formatCurrency

@Composable
fun ProductDetailScreen(productId: String?, goToCart : () -> Unit) {
    val viewModel = remember { ProductDetailViewModel(ProductRepository()) }
    val product by viewModel.product.collectAsState()
    val scrollState = rememberScrollState()
    var quantity by remember { mutableStateOf(1) }
    var showAddedToCartSnackbar by remember { mutableStateOf(false) }
    var showOutOfStockSnackbar by remember { mutableStateOf(false) }
    val scaffoldState = rememberScaffoldState()
    val backDispatcher = LocalOnBackPressedDispatcherOwner.current?.onBackPressedDispatcher

    LaunchedEffect(productId) {
        productId?.toIntOrNull()?.let { id ->
            viewModel.getProductById(id)
        }
    }

    // Reset quantity to 1 or 0 (if out of stock) when product changes
    LaunchedEffect(product) {
        product?.let { prod ->
            quantity = if (prod.quantity > 0) 1 else 0
        }
    }

    LaunchedEffect(showAddedToCartSnackbar) {
        if (showAddedToCartSnackbar) {
            scaffoldState.snackbarHostState.showSnackbar(
                message = "Produk berhasil ditambahkan ke keranjang",
                actionLabel = "Tutup"
            )
            showAddedToCartSnackbar = false
        }
    }

    LaunchedEffect(showOutOfStockSnackbar) {
        if (showOutOfStockSnackbar) {
            scaffoldState.snackbarHostState.showSnackbar(
                message = "Maaf, produk ini tidak tersedia",
                actionLabel = "Tutup"
            )
            showOutOfStockSnackbar = false
        }
    }

    Scaffold(
        scaffoldState = scaffoldState,
        topBar = {
            TopAppBar(
                title = { Text("Rincian Produk") },
                navigationIcon = {
                    IconButton(onClick = { backDispatcher?.onBackPressed() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Kembali")
                    }
                },
                actions = {
                    IconButton(onClick = { goToCart() }) {
                        Icon(Icons.Default.ShoppingCart, contentDescription = "Keranjang Belanja")
                    }
                },
                backgroundColor = MaterialTheme.colors.primary,
                contentColor = Color.White,
                elevation = 8.dp
            )
        },
        bottomBar = {
            product?.let { prod ->
                Surface(
                    elevation = 8.dp,
                    color = MaterialTheme.colors.surface
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Total",
                                style = MaterialTheme.typography.caption
                            )
                            Text(
                                text = formatCurrency(prod.price * quantity),
                                style = MaterialTheme.typography.h6,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colors.primary
                            )
                        }

                        Button(
                            onClick = {
                                if (prod.quantity > 0) {
                                    viewModel.addToCart(prod, quantity)
                                    showAddedToCartSnackbar = true
                                } else {
                                    showOutOfStockSnackbar = true
                                }
                            },
                            modifier = Modifier
                                .height(48.dp)
                                .width(180.dp),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(
                                backgroundColor = if (prod.quantity > 0) MaterialTheme.colors.primary else Color.Gray,
                                contentColor = Color.White
                            ),
                            enabled = prod.quantity > 0
                        ) {
                            Icon(Icons.Default.ShoppingCart, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(if (prod.quantity > 0) "Tambah ke Keranjang" else "Stok Habis")
                        }
                    }
                }
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            AnimatedVisibility(
                visible = product == null,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(
                        color = MaterialTheme.colors.primary,
                        modifier = Modifier.size(48.dp)
                    )
                }
            }

            product?.let { prod ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(scrollState)
                ) {
                    // Product Image Section with Rating Badge
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(300.dp)
                    ) {
                        AsyncImage(
                            model = prod.image,
                            contentDescription = "Gambar Produk",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.fillMaxSize()
                        )

                        // Rating Badge
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(16.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colors.primary.copy(alpha = 0.8f))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Default.Star,
                                    contentDescription = null,
                                    tint = Color.Yellow,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "4.8",
                                    color = Color.White,
                                    style = MaterialTheme.typography.caption,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        // Stock status badge for zero stock
                        if (prod.quantity <= 0) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(16.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color.Red.copy(alpha = 0.8f))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "Stok Habis",
                                    color = Color.White,
                                    style = MaterialTheme.typography.caption,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    // Product Info Section
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        // Title & Price
                        Text(
                            text = prod.title,
                            style = MaterialTheme.typography.h5,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = formatCurrency(prod.price),
                            style = MaterialTheme.typography.h6,
                            color = MaterialTheme.colors.primary,
                            fontWeight = FontWeight.Bold
                        )

                        // Category & Stock with Icons
                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colors.primary.copy(alpha = 0.1f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        Icons.Default.Category,
                                        contentDescription = null,
                                        tint = MaterialTheme.colors.primary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        "Kategori",
                                        style = MaterialTheme.typography.caption,
                                        color = Color.Gray
                                    )
                                    Text(
                                        text = prod.category,
                                        style = MaterialTheme.typography.body2
                                    )
                                }
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (prod.quantity > 0)
                                                MaterialTheme.colors.primary.copy(alpha = 0.1f)
                                            else
                                                Color.Red.copy(alpha = 0.1f)
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        Icons.Default.Inventory,
                                        contentDescription = null,
                                        tint = if (prod.quantity > 0)
                                            MaterialTheme.colors.primary
                                        else
                                            Color.Red,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        "Persediaan",
                                        style = MaterialTheme.typography.caption,
                                        color = Color.Gray
                                    )
                                    Text(
                                        text = "${prod.quantity} pcs",
                                        style = MaterialTheme.typography.body2,
                                        color = if (prod.quantity > 0) Color.Unspecified else Color.Red
                                    )
                                }
                            }
                        }

                        // Quantity Selector - only show if stock is available
                        if (prod.quantity > 0) {
                            Spacer(modifier = Modifier.height(24.dp))

                            Text(
                                text = "Jumlah",
                                style = MaterialTheme.typography.subtitle1,
                                fontWeight = FontWeight.Bold
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .padding(4.dp)
                                    .width(150.dp)
                            ) {
                                IconButton(
                                    onClick = { if (quantity > 1) quantity-- },
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(Color.LightGray.copy(alpha = 0.3f))
                                ) {
                                    Icon(
                                        Icons.Default.Remove,
                                        contentDescription = "Decrease",
                                        tint = if (quantity > 1) MaterialTheme.colors.primary else Color.Gray
                                    )
                                }

                                Text(
                                    text = quantity.toString(),
                                    style = MaterialTheme.typography.body1,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier
                                        .weight(1f)
                                        .padding(horizontal = 8.dp),
                                    textAlign = TextAlign.Center
                                )

                                IconButton(
                                    onClick = { if (quantity < prod.quantity) quantity++ },
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(Color.LightGray.copy(alpha = 0.3f))
                                ) {
                                    Icon(
                                        Icons.Default.Add,
                                        contentDescription = "Increase",
                                        tint = if (quantity < prod.quantity) MaterialTheme.colors.primary else Color.Gray
                                    )
                                }
                            }

                            if (prod.quantity > 0) {
                                Text(
                                    text = "Tersedia: ${prod.quantity} pcs",
                                    style = MaterialTheme.typography.caption,
                                    color = Color.Gray,
                                    modifier = Modifier.padding(start = 4.dp, top = 4.dp)
                                )
                            }
                        } else {
                            Spacer(modifier = Modifier.height(24.dp))

                            Text(
                                text = "Produk ini sedang tidak tersedia",
                                style = MaterialTheme.typography.subtitle2,
                                color = Color.Red,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color.Red.copy(alpha = 0.1f))
                                    .padding(12.dp),
                                textAlign = TextAlign.Center
                            )
                        }

                        // Description Section
                        Spacer(modifier = Modifier.height(24.dp))

                        Text(
                            text = "Deskripsi",
                            style = MaterialTheme.typography.subtitle1,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = prod.description,
                            style = MaterialTheme.typography.body2,
                            color = Color.DarkGray,
                            lineHeight = 24.sp
                        )

                        // Bottom space for the bottom bar
                        Spacer(modifier = Modifier.height(80.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun SpecificationRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.body2,
            color = Color.Gray
        )
        Text(
            text = value,
            style = MaterialTheme.typography.body2,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
fun Modifier.border(
    width: Dp,
    color: Color,
    shape: RoundedCornerShape
) = this.then(
    Modifier.drawBehind {
        drawRoundRect(
            color = color,
            style = Stroke(width = width.toPx()),
            cornerRadius = CornerRadius(x = 20f, y = 20f),
        )
    }
)