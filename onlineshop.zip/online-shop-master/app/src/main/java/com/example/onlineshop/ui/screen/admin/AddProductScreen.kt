package com.example.onlineshop.ui.screen.admin

import android.net.Uri
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.rememberAsyncImagePainter
import com.example.onlineshop.data.model.Product
import com.example.onlineshop.data.repository.ProductRepository
import com.example.onlineshop.utils.ImgurUploader
import kotlinx.coroutines.launch

@Composable
fun AddProductScreen(
    navController: NavController
) {
    val coroutineScope = rememberCoroutineScope()
    val productRepository = remember { ProductRepository() }
    val scaffoldState = rememberScaffoldState()
    val context = LocalContext.current
    val scrollState = rememberScrollState()
    val imgurUploader = remember { ImgurUploader(context) }

    var isSaving by remember { mutableStateOf(false) }
    var isUploadingImage by remember { mutableStateOf(false) }

    // Form fields
    var title by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var stock by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Others") }
    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }
    var currentImageUrl by remember { mutableStateOf("") }

    // Category dropdown
    val categories = listOf("Makeup", "Skincare", "Haircare", "Bodycare")
    var expandedCategory by remember { mutableStateOf(false) }

    // Image picker
    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            selectedImageUri = it
        }
    }

    // Validate form
    val isFormValid = remember(title, price, stock, currentImageUrl) {
        title.isNotBlank() &&
                price.isNotBlank() &&
                price.toDoubleOrNull() != null &&
                (price.toDoubleOrNull() ?: 0.0) > 0 &&
                stock.isNotBlank() &&
                stock.toIntOrNull() != null &&
                (stock.toIntOrNull() ?: 0) >= 0 &&
                currentImageUrl.isNotBlank()
    }

    Scaffold(
        scaffoldState = scaffoldState,
        topBar = {
            TopAppBar(
                title = {Text("Tambah Produk")},
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                backgroundColor = MaterialTheme.colorScheme.surface
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(scrollState)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Product Image Section
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.LightGray.copy(alpha = 0.3f))
                    .clickable { imagePickerLauncher.launch("image/*") }
                    .border(1.dp, Color.Gray.copy(alpha = 0.5f), RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                if (isUploadingImage) {
                    // Show loading indicator when uploading image
                    CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                } else if (selectedImageUri != null) {
                    // Show selected image
                    Image(
                        painter = rememberAsyncImagePainter(selectedImageUri),
                        contentDescription = "Selected Product Image",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit
                    )
                } else if (currentImageUrl.isNotEmpty()) {
                    // Show current image
                    Image(
                        painter = rememberAsyncImagePainter(currentImageUrl),
                        contentDescription = "Current Product Image",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit
                    )
                } else {
                    // Show placeholder
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PhotoCamera,
                            contentDescription = "Add Photo",
                            modifier = Modifier.size(48.dp),
                            tint = Color.Gray
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Tekan untuk memilih gambar", color = Color.Gray)
                    }
                }
            }

            // Upload button for image
            if (selectedImageUri != null) {
                Button(
                    onClick = {
                        coroutineScope.launch {
                            isUploadingImage = true
                            try {
                                val imageUrl = imgurUploader.uploadImage(selectedImageUri!!)
                                if (imageUrl?.isNotEmpty() ?: false) {
                                    currentImageUrl = imageUrl.toString()
                                    selectedImageUri = null
                                    scaffoldState.snackbarHostState.showSnackbar("Gambar berhasil diupload")
                                } else {
                                    scaffoldState.snackbarHostState.showSnackbar("Gagal mengupload gambar")
                                }
                            } catch (e: Exception) {
                                Log.e("AddProductScreen", "Image upload error: ${e.message}", e)
                                scaffoldState.snackbarHostState.showSnackbar("Error uploading image: ${e.message}")
                            } finally {
                                isUploadingImage = false
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(backgroundColor = MaterialTheme.colorScheme.primary),
                    enabled = !isUploadingImage
                ) {
                    Text("Upload Gambar", color = Color.White)
                }
            }

            Text(
                text = "Rincian Produk",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            // Title
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Nama Produk") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            // Price and Stock
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                OutlinedTextField(
                    value = price,
                    onValueChange = { price = it },
                    label = { Text("Harga (Rp)") },
                    modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true
                )

                OutlinedTextField(
                    value = stock,
                    onValueChange = { stock = it },
                    label = { Text("Stok") },
                    modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true
                )
            }

            // Category
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Kategori",
                    fontSize = 14.sp,
                    color = Color.Gray,
                    modifier = Modifier.padding(start = 4.dp, bottom = 4.dp)
                )

                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = category,
                        onValueChange = { },
                        modifier = Modifier.fillMaxWidth(),
                        trailingIcon = {
                            Icon(
                                Icons.Default.ArrowDropDown,
                                contentDescription = "Select Category",
                                modifier = Modifier.clickable { expandedCategory = true }
                            )
                        },
                        readOnly = true
                    )

                    DropdownMenu(
                        expanded = expandedCategory,
                        onDismissRequest = { expandedCategory = false },
                        modifier = Modifier.fillMaxWidth(0.9f)
                    ) {
                        categories.forEach { option ->
                            DropdownMenuItem(onClick = {
                                category = option
                                expandedCategory = false
                            }) {
                                Text(text = option)
                            }
                        }
                    }
                }
            }

            // Description
            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("Deskripsi") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp),
                maxLines = 6
            )

            // Save Button
            Button(
                onClick = {
                    if (isFormValid) {
                        coroutineScope.launch {
                            isSaving = true
                            try {
                                val newProduct = Product(
                                    id = 0,
                                    title = title,
                                    price = price.toDoubleOrNull() ?: 0.0,
                                    quantity = stock.toIntOrNull() ?: 0,
                                    description = description,
                                    category = category,
                                    image = currentImageUrl
                                )

                                // Add product to Firestore
                                productRepository.addProductToFirestore(newProduct)

                                scaffoldState.snackbarHostState.showSnackbar("Produk berhasil ditambahkan")
                                navController.popBackStack()
                            } catch (e: Exception) {
                                scaffoldState.snackbarHostState.showSnackbar("Error adding product: ${e.message}")
                            } finally {
                                isSaving = false
                            }
                        }
                    } else {
                        coroutineScope.launch {
                            scaffoldState.snackbarHostState.showSnackbar("Silahkan isi semua data")
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp)
                    .height(50.dp),
                colors = ButtonDefaults.buttonColors(backgroundColor = MaterialTheme.colorScheme.primary),
                enabled = isFormValid && !isSaving && !isUploadingImage
            ) {
                if (isSaving) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(24.dp),
                        color = Color.White,
                        strokeWidth = 2.dp
                    )
                } else {
                    Text("Tambah Produk", color = Color.White, fontSize = 16.sp)
                }
            }
        }
    }
}