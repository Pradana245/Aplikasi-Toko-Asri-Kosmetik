package com.example.onlineshop.ui.viewModel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.onlineshop.data.model.Product
import com.example.onlineshop.data.repository.ProductRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class AdminDashboardViewModel(private val repository: ProductRepository) : ViewModel() {

    private val _products = MutableStateFlow<List<Product>>(emptyList())
    val products = _products.asStateFlow()

    fun fetchProducts() {
        viewModelScope.launch {
            try {
                val data = repository.getProductsFromFirestore()
                _products.value = data
            } catch (e: Exception) {
                _products.value = emptyList() // Jangan crash, biarkan kosong
                println("Error fetching products: ${e.message}")
            }
        }
    }


    fun addProduct(product: Product) {
        viewModelScope.launch {
            repository.addProductToFirestore(product)
            fetchProducts() // Refresh data setelah menambah produk
        }
    }

    fun updateProduct(product: Product) {
        viewModelScope.launch {
            repository.updateProductInFirestore(product)
            fetchProducts() // Refresh data setelah mengedit produk
        }
    }
}
