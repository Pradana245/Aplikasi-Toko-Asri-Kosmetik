package com.example.onlineshop.ui.screen.user

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.Button
import androidx.compose.material.ButtonDefaults
import androidx.compose.material.Card
import androidx.compose.material.CircularProgressIndicator
import androidx.compose.material.Divider
import androidx.compose.material.Icon
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.onlineshop.R
import com.example.onlineshop.ui.viewModel.TransactionViewModel
import com.example.onlineshop.utils.formatCurrency

@Composable
fun ConfirmationPaymentScreen(
    transactionId: String,
    totalAmount: Double,
    transactionViewModel: TransactionViewModel = viewModel(),
    onPayment: () -> Unit
) {
    var paymentStatus by remember { mutableStateOf("Pending") }
    var isLoading by remember { mutableStateOf(false) }
    var showSuccess by remember { mutableStateOf(false) }

    val checkScale by animateFloatAsState(
        targetValue = if (showSuccess) 1f else 0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        )
    )

    LaunchedEffect(transactionId) {
        transactionViewModel.getTransactionStatus(transactionId) { status ->
            paymentStatus = status
            if (status == "Paid" || status == "Confirmed") {
                showSuccess = true
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            AnimatedVisibility(
                visible = showSuccess,
                enter = fadeIn() + slideInVertically(
                    initialOffsetY = { -200 }
                ),
                exit = fadeOut()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(120.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFE8F5E9))
                            .padding(16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.CheckCircle,
                            contentDescription = "Pembayaran Berhasil",
                            modifier = Modifier
                                .size(80.dp)
                                .scale(checkScale),
                            tint = Color(0xFF43A047)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "Pembayaran Kamu telah Terkonfirmasi",
                        style = MaterialTheme.typography.h6,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF43A047)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Terima kasih telah berbelanja di toko kami",
                        style = MaterialTheme.typography.body1,
                        textAlign = TextAlign.Center,
                        color = Color.Gray
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    Button(
                        onClick = onPayment,
                        modifier = Modifier
                            .fillMaxWidth(0.7f)
                            .height(50.dp),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(
                            backgroundColor = MaterialTheme.colors.primary
                        )
                    ) {
                        Text(
                            text = "Lanjutkan Belanja",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .alpha(if (showSuccess) 0f else 1f),
                shape = RoundedCornerShape(12.dp),
                elevation = 4.dp
            ) {
                Column(
                    modifier = Modifier
                        .padding(20.dp)
                        .verticalScroll(rememberScrollState()),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    painterResource( R.mipmap.qris_code).let { painter ->
                        Image(
                            painter = painter,
                            contentDescription = "QR Code",
                            modifier = Modifier
                                .size(500.dp)
                                .padding(bottom = 16.dp)
                        )
                    }
                    Text(
                        text = "Konfirmasi Pembayaran",
                        style = MaterialTheme.typography.h6,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    Text(
                        text = "Silahkan melakukan konfirmasi pembayaran",
                        style = MaterialTheme.typography.subtitle2,
                        color = Color.Gray,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )

                    Divider(modifier = Modifier.padding(vertical = 8.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "ID Transaksi",
                            style = MaterialTheme.typography.body2,
                            color = Color.Gray
                        )

                        Text(
                            text = transactionId,
                            style = MaterialTheme.typography.body2,
                            fontWeight = FontWeight.Medium,
                        )
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Total Harga",
                            style = MaterialTheme.typography.body2,
                            color = Color.Gray
                        )

                        Text(
                            text = formatCurrency(totalAmount),
                            style = MaterialTheme.typography.body1,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colors.primary
                        )
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Status",
                            style = MaterialTheme.typography.body2,
                            color = Color.Gray
                        )

                        val statusColor = when (paymentStatus) {
                            "Paid" -> Color(0xFF43A047)
                            "Pending" -> Color(0xFFFFA000)
                            "Failed" -> Color(0xFFE53935)
                            else -> Color.Gray
                        }

                        val statusText = when (paymentStatus) {
                            "Paid" -> "Sudah Dibayar"
                            "Pending" -> "Menunggu Pembayaran"
                            "Failed" -> "Pembayaran Gagal"
                            else -> "Unknown"
                        }

                        Text(
                            text = statusText,
                            style = MaterialTheme.typography.body2,
                            fontWeight = FontWeight.Medium,
                            color = statusColor
                        )
                    }

                    Divider(modifier = Modifier.padding(vertical = 8.dp))

                    Button(
                        onClick = {
                            isLoading = true
                            transactionViewModel.markAsPaid(transactionId) { success ->
                                isLoading = false
                                if (success) {
                                    paymentStatus = "Paid"
                                    showSuccess = true
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(
                            backgroundColor = MaterialTheme.colors.primary,
                            disabledBackgroundColor = Color.Gray
                        ),
                        enabled = !isLoading && paymentStatus == "Pending"
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(24.dp),
                                color = Color.White,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Text(
                                text = "Konfirmasi Pembayaran",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}